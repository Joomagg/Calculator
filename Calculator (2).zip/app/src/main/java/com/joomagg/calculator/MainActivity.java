package com.joomagg.calculator;

import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.String;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button[] = new Button[16];   // 0 ~ 9, +, -, *, /, =, c
    TextView tv;    // shows user input or calculating output
    String mop = "0.0";   // main operand
    String sop = "0.0";   // sub operand
    char opr = 'n';    // operator
    boolean opr_pressed = false;    // whether operator is pressed or not
                                    // for duplicated operator

    @Override
    public void onConfigurationChanged (Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            setContentView(R.layout.activity_main_land);
            Log.d("orientation", "landscape");
            tv = (TextView)findViewById(R.id.tv);
            tv.setText(mop);
        }
        else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)
        {
            setContentView(R.layout.activity_main);
            Log.d("orientation", "portrait");
            tv = (TextView)findViewById(R.id.tv);
            tv.setText(mop);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* getting and setting TextView value */
        tv = (TextView)findViewById(R.id.tv);
        tv.setText(mop);

        /* getting Button */
        button[0] = (Button)findViewById(R.id.button0);
        button[1] = (Button)findViewById(R.id.button1);
        button[2] = (Button)findViewById(R.id.button2);
        button[3] = (Button)findViewById(R.id.button3);
        button[4] = (Button)findViewById(R.id.button4);
        button[5] = (Button)findViewById(R.id.button5);
        button[6] = (Button)findViewById(R.id.button6);
        button[7] = (Button)findViewById(R.id.button7);
        button[8] = (Button)findViewById(R.id.button8);
        button[9] = (Button)findViewById(R.id.button9);
        button[10] = (Button)findViewById(R.id.buttonPlus);
        button[11] = (Button)findViewById(R.id.buttonMinus);
        button[12] = (Button)findViewById(R.id.buttonMultiplier);
        button[13] = (Button)findViewById(R.id.buttonDivider);
        button[14] = (Button)findViewById(R.id.buttonEqual);
        button[15] = (Button)findViewById(R.id.buttonClear);

        /* implement event listener */
        for (int i=0; i<16; i=i+1)
            button[i].setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        // if v is numeric button
        for (int i=0; i<10; i=i+1)
            if (v.getId() == button[i].getId())
            {
                // check if start with '0'
                if (mop.equals("0.0") || mop.equals("0"))
                    mop = Integer.toString(i);
                // concat the userinput number
                else
                    mop = mop.concat(Integer.toString(i));
                tv.setText(mop);
                opr_pressed = false;
                break;
            }
        // if button '+' clicked
        if (v.getId() == button[10].getId())
        {
            // if duplicated operator
            if (opr_pressed)
                opr = '+';
            // if first operator
            else if (opr == 'n')
            {
                opr_pressed = true;
                sop = mop;
                mop = "0.0";
                opr = '+';
            }
            // if duplicated operator but needs calculating
            else if(!opr_pressed && opr !='+')
            {
                calculate(true);
                opr_pressed = true;
                opr = '+';
            }
            // calculate
            else
                calculate(true);
        }
        // if button '-' clicked
        else if (v.getId() == button[11].getId())
        {
            // if duplicated operator
            if (opr_pressed)
                opr = '-';
            // if first operator
            else if (opr == 'n')
            {
                opr_pressed = true;
                sop = mop;
                mop = "0.0";
                opr = '-';
            }
            // if duplicated operator but needs calculating
            else if(!opr_pressed && opr !='-')
            {
                calculate(true);
                opr_pressed = true;
                opr = '-';
            }
            // calculate
            else
                calculate(true);
        }
        // if button '*' clicked
        else if (v.getId() == button[12].getId())
        {
            // if duplicated operator
            if (opr_pressed)
                opr = '*';
            // if first operator
            else if (opr == 'n')
            {
                opr_pressed = true;
                sop = mop;
                mop = "0.0";
                opr = '*';
            }
            // if duplicated operator but needs calculating
            else if(!opr_pressed && opr !='*')
            {
                calculate(true);
                opr_pressed = true;
                opr = '*';
            }
            // calculate
            else
                calculate(true);
        }
        // if button '/' clicked
        else if (v.getId() == button[13].getId())
        {
            // if duplicated operator
            if (opr_pressed)
                opr = '/';
            // if first operator
            else if (opr == 'n')
            {
                opr_pressed = true;
                sop  = mop;
                mop = "0.0";
                opr = '/';
            }
            // if duplicated operator but needs calculating
            else if(!opr_pressed && opr !='/')
            {
                calculate(true);
                opr_pressed = true;
                opr = '/';
            }
            // calculate
            else
                calculate(true);
        }
        // if button '=' clicked
        else if (v.getId() == button[14].getId())
        {

            if (opr == 'n')
            {
                sop = "0.0";
                mop = "0.0";
            } else {
                calculate(false);
                opr = 'n';
                opr_pressed = false;
            }
        }
        // if button 'c' clicked, initialize
        else if (v.getId() == button[15].getId())
        {
            opr = 'n';
            opr_pressed = false;
            sop = "0.0";
            mop = "0.0";
            tv.setText(mop);
        }
        debug();    // for debugging
    }

    // calculate
    private void calculate(boolean byOperator)
    {

        double b = Double.parseDouble(mop);
        double a = Double.parseDouble(sop);

        switch (opr)
        {
            case '+':
                mop = "0.0";
                sop = Double.toString(a+b);
                break;
            case '-':
                mop = "0.0";
                sop = Double.toString(a-b);
                break;
            case '*':
                mop = "0.0";
                sop = Double.toString(a*b);
                break;
            case '/':
                try {   // handling division by zero
                    if (b == 0.0)
                        throw (new Exception("Division By Zero"));
                    mop = "0.0";
                    sop = Double.toString(a / b);
                }
                catch (Exception e)
                {
                    mop = "0.0";
                    sop = "0.0";
                    opr_pressed = false;
                    opr = 'n';
                    Toast.makeText(MainActivity.this, "Division By Zero", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        // if not calculated by operator
        if (!byOperator)
            opr_pressed = false;
        tv.setText(sop);
        Log.d("(debug)", "calculated");
    }

    // for debugging
    private void debug()
    {
        Log.d("(dbg)Main Operand", mop);
        Log.d("(dbg)Sub Operand", sop);
        Log.d("(dbg)Operator", Character.toString(opr));
        Log.d("(dbg)Pressed", Boolean.toString(opr_pressed));
        Log.d("\n","\n");
    }
}
